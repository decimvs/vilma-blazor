﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vilma.Blazor
{
    public enum DropdownDirections
    {
        Down,
        DownCentered,
        Up,
        UpCentered,
        End,
        Start
    }
}
